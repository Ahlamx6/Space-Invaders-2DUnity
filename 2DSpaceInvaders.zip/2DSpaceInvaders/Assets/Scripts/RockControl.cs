using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RockControl : MonoBehaviour
{
     float speed;
     public GameObject ExplodeEffect;
    // Start is called before the first frame update
    void Start()
    {
        speed = Random.Range(1.5f, 2.5f);
        GetComponent<Rigidbody2D>().velocity = transform.up * -1 * speed;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Bullet")
        {
            Destroy(other.gameObject);
            //Instantiate(ExplodeEffect, transform.position, Quaternion.identity);
            GetComponent<Animator>().enabled = true;
            GetComponent<CircleCollider2D>().enabled = false;
            GetComponent<Rigidbody2D>().velocity = Vector2.zero;
            Destroy(this.gameObject,0.35f);

            ScoreManager.instance.AddScore(5);

            AudioManager.instance.OnRockExplode();
        }
    }
}
