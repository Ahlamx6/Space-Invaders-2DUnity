using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class ScoreManager : MonoBehaviour
{
    public static ScoreManager instance;
    public int Curruntscore = 0;

    public TextMeshProUGUI Scoretext;
    public TextMeshProUGUI HighScoretext;
    public int HighScoretcount =0;

    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
       
       HighScoretcount = PlayerPrefs.GetInt("highscore");
        Scoretext.text = "SCORE : 0";
        
    }

    public int GetCurrentScore()
    {
        return Curruntscore;
    }

    public void AddScore(int value)
    {
        Curruntscore += value;
        UpdateScore();
        
    }

    private void UpdateScore()
    {

        Scoretext.text = "SCORE : " + Curruntscore.ToString();
        HighScoretext.text = "HIGH SCORE : "+ HighScoretcount.ToString();

        if(Curruntscore > HighScoretcount)
        {
            PlayerPrefs.SetInt("highscore", Curruntscore);
        }

    }
    
}

