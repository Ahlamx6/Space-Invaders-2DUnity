using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class LevelManager : MonoBehaviour
{
    public static LevelManager instance;
    [SerializeField] GameObject gameover;
    public bool isGameOver = false;
    public int max_lives = 3;
    public GameObject Playerprefab;
    public int CurrentLives;
    public TextMeshProUGUI LivesText;
    public bool isRespawning = false;

    private void Awake()
    {
        instance = this;
        CurrentLives = max_lives;
        UpdateLivesText();
    }

     public void ShowGameOver()
     {
        gameover.SetActive(true);
        isGameOver = true;
     }

     private void Update()
    {
        if(Input.GetKeyDown(KeyCode.R))
        RestartGame();
    }

    public void RestartGame()
    {
        SceneManager.LoadSceneAsync(0);
    }

    public void UpdateLivesText()
    {
      LivesText.text = " : " + CurrentLives. ToString();
    }

    public void ReSpawnPlayer()
    {
        Invoke("ReintPlayer", 2f);
        isRespawning = true;
    }

     void ReintPlayer()
     {
        Instantiate(Playerprefab, new Vector2(0f, -3.5f), Quaternion.identity);

     }
}
