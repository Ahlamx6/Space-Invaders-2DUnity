using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    public float speed = 3f;
    float player_direction = 0;
    public float xmin, xmax;
    public GameObject bulletPrefab;
    public GameObject ExplodeParticles;
    

    private void Start()
    {
        if(LevelManager.instance.CurrentLives == LevelManager.instance.max_lives)
          return;
        GetComponent<SpriteRenderer>().color = new Color32(255,255,255,80);
        Invoke("Respawncomplate", 3f);
    }

    void Respawncomplate()
    {
        LevelManager.instance.isRespawning = false;
        GetComponent<SpriteRenderer>().color = new Color32(255,255,255,255);

    }
    void Update()
    {
        player_direction = Input.GetAxisRaw("Horizontal");
        if((player_direction <0 && transform.position.x > xmin) || (player_direction > 0 && transform.position.x < xmax))
         transform.Translate(Vector2.right * player_direction * speed* Time.deltaTime);

        if(Input.GetKeyDown(KeyCode.Space))
          Shoot();
        
    }

    void Shoot()
    {
        Instantiate(bulletPrefab, transform.position, Quaternion.identity);
        AudioManager.instance.OnBulletFired();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(LevelManager.instance.isRespawning)
          return;

        Instantiate(ExplodeParticles, transform.position, Quaternion.identity);
        AudioManager.instance.onplayerExplode();
        LevelManager.instance.CurrentLives--;
         Destroy(gameObject);
         LevelManager.instance.UpdateLivesText();
        if(LevelManager.instance.CurrentLives <=0)
        {
       
        LevelManager.instance.ShowGameOver();
        }
        else 
        {
            
            LevelManager.instance.ReSpawnPlayer();
        }
    }
}
