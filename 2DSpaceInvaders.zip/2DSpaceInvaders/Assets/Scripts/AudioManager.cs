using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{

    [SerializeField] private AudioClip[] ExplodeSound;
    [SerializeField] private AudioClip[] ShootSFX;
    public static AudioManager instance;

    private void Awake()
    {
        instance = this;
    }

    public void OnBulletFired()
    {
        GetComponent<AudioSource>().PlayOneShot(ShootSFX[0]);
    }

    public void OnRockExplode()
    {
        GetComponent<AudioSource>().PlayOneShot(ExplodeSound[0]);
    }

    public void OnEnemyExplode()
    {
        GetComponent<AudioSource>().PlayOneShot(ExplodeSound[1]);
    }

    public void onplayerExplode()
    {
        GetComponent<AudioSource>().PlayOneShot(ExplodeSound[2]);

    }
}

