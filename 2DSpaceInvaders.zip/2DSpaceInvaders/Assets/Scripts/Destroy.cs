using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{
    [SerializeField] float explodeTime;
    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject, explodeTime);
    }

}
