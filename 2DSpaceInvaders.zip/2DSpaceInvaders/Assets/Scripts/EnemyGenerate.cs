using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyGenerate : MonoBehaviour
{
    public GameObject enemyPrefab;
    Vector2 spawnPostion;

    // Start is called before the first frame update
    void Start()
    {
        spawnPostion = new Vector2();
        StartCoroutine(Generate());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator Generate ()
    {
        spawnPostion = new Vector2(Random.Range(-7f,7f), transform.position.y);
        yield return new WaitForSeconds(0.5f);
        Instantiate(enemyPrefab, spawnPostion, Quaternion.identity);

        yield return new WaitForSeconds(Random.Range(0.5f,5f));
        StartCoroutine(Generate());
    }
}
